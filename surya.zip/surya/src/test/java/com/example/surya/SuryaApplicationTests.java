package com.example.surya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuryaApplicationTests {

	@Test
	void contextLoads() {
	}

}
